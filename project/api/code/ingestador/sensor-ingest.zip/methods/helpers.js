
// Función que comprueba que el mensaje tienes las características necesarias
// Devuelve true si es correcto y false si es incorrecto
function IsCorrectMessage(payload) {

    // Comprobar que nos llegan bytes de datos
    if (payload.uplink_message.decoded_payload == undefined || payload.uplink_message.decoded_payload == null) return false;
    // si no me llega timestamp, salimos
    if (payload.received_at == undefined || payload.received_at == null) return false;
    // Si no llega device_id, salimos
    if (payload.end_device_ids.device_id == undefined || payload.end_device_ids.device_id == null) return false;
    // Si no llega application_id, fuera
    if (payload.end_device_ids.application_ids.application_id == undefined || payload.end_device_ids.application_ids.application_id == null) return false;

    return true;

}

module.exports = { IsCorrectMessage };
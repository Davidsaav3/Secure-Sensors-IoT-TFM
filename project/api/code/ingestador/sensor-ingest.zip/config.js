// Ingest API Token
// jvberna
authorization = 'lxNMgQyhkcxEfElVlCMknwAMfikabN;*rHw7ie5J1J8XOr*%Rj0J%uRkIGmzOV0YyIbWYFUZTS9+kp4HfBeyC2J@nV+ET__'
urlIngest = 'https://ingest.smartua.es'
// lucia
// authorization = 'PiAeOdIxD9FKNdd70FqAwPu8FtP3J9;e0bgfV..RPRcs8B*mCmSOHDN__0%PqKg9U@yYXVmn5BOb+VG+ERiBsFnefGQ-Uip'


// Topic Y
mqttQue='mqtt://eu1.cloud.thethings.network:1883'

// Aplicación ua-sensors
appID='ua-sensor@ttn'
accessKey='NNSXS.VHCKXEROUIBVRURMLCECRVTHRF77EGFRV2G3RNI.GCFZXXJF4VZCBH5V7YHHNT3OWKLCTPDVLRU74XVWFAPQ7IMI2S2A'


/*
// Aplicación testing
appID='jv-testing@ttn'
accessKey='NNSXS.PKX2GNR3ZOEOCPHEFWCBEIKYECFK34YXBPDYTZA.DCOPX2K2KAHWXHBD2BMTQM3F55V5LXY45AVDZEBGSX2MEXMSGXYA'
*/

// suscribe es un array de colas a las que se suscribe el usuario
suscribe=['v3/'+appID+'/devices/+/up']

module.exports = {
    authorization,
    urlIngest,
    appID,
    accessKey,
    suscribe, 
    mqttQue
}